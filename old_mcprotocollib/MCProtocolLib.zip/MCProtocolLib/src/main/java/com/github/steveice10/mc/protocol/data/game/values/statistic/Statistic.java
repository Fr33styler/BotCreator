package com.github.steveice10.mc.protocol.data.game.values.statistic;

public interface Statistic {
}
