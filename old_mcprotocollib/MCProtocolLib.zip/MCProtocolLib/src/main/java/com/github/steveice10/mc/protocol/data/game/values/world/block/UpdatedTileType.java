package com.github.steveice10.mc.protocol.data.game.values.world.block;

public enum UpdatedTileType {

    MOB_SPAWNER,
    COMMAND_BLOCK,
    BEACON,
    SKULL,
    FLOWER_POT,
    BANNER;

}
