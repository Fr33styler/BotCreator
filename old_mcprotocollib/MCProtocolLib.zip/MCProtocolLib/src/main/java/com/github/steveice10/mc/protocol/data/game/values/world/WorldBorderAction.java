package com.github.steveice10.mc.protocol.data.game.values.world;

public enum WorldBorderAction {
    SET_SIZE,
    LERP_SIZE,
    SET_CENTER,
    INITIALIZE,
    SET_WARNING_TIME,
    SET_WARNING_BLOCKS;
}
