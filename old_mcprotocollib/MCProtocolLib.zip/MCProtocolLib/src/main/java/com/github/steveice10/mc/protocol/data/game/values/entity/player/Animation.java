package com.github.steveice10.mc.protocol.data.game.values.entity.player;

public enum Animation {

    SWING_ARM,
    DAMAGE,
    LEAVE_BED,
    EAT_FOOD,
    CRITICAL_HIT,
    ENCHANTMENT_CRITICAL_HIT;

}
