package com.github.steveice10.mc.protocol.data.game.values.entity;

public enum HangingDirection implements ObjectData {

    SOUTH,
    WEST,
    NORTH,
    EAST;

}
