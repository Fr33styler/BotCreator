package com.github.steveice10.mc.protocol.data.game.values.scoreboard;

public enum NameTagVisibility {

    ALWAYS,
    NEVER,
    HIDE_FOR_OTHER_TEAMS,
    HIDE_FOR_OWN_TEAM;

}
