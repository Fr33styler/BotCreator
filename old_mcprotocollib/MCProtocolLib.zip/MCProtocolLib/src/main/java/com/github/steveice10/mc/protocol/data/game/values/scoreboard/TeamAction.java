package com.github.steveice10.mc.protocol.data.game.values.scoreboard;

public enum TeamAction {

    CREATE,
    REMOVE,
    UPDATE,
    ADD_PLAYER,
    REMOVE_PLAYER;

}
