package com.github.steveice10.mc.protocol.data.game.values;

public enum TitleAction {
    TITLE,
    SUBTITLE,
    TIMES,
    CLEAR,
    RESET;
}
