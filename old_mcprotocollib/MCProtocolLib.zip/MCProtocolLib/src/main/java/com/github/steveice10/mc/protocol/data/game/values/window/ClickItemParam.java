package com.github.steveice10.mc.protocol.data.game.values.window;


public enum ClickItemParam implements WindowActionParam {

    LEFT_CLICK,
    RIGHT_CLICK;

}
