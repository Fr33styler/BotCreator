package com.github.steveice10.mc.protocol.data.game.values.scoreboard;

public enum ScoreboardAction {

    ADD_OR_UPDATE,
    REMOVE;

}
