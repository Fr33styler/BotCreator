package com.github.steveice10.mc.protocol.data.game.values.world.effect;

public interface WorldEffect {
}
