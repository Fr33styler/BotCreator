package com.github.steveice10.mc.protocol.data.game.values;

public enum MessageType {

    CHAT,
    SYSTEM,
    NOTIFICATION;

}
