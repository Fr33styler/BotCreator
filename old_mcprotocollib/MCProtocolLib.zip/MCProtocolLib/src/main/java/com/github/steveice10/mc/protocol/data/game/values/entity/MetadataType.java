package com.github.steveice10.mc.protocol.data.game.values.entity;

public enum MetadataType {

    BYTE,
    SHORT,
    INT,
    FLOAT,
    STRING,
    ITEM,
    POSITION,
    ROTATION;

}
