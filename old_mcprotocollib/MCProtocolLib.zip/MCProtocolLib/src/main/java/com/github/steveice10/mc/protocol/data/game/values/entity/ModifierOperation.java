package com.github.steveice10.mc.protocol.data.game.values.entity;

public enum ModifierOperation {

    ADD,
    ADD_MULTIPLIED,
    MULTIPLY;

}
