package com.github.steveice10.mc.protocol.data.game.values.setting;

public enum ChatVisibility {

    FULL,
    SYSTEM,
    HIDDEN;

}
