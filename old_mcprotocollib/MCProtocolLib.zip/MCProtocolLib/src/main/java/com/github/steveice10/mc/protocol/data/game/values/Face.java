package com.github.steveice10.mc.protocol.data.game.values;

public enum Face {

    BOTTOM,
    TOP,
    EAST,
    WEST,
    NORTH,
    SOUTH,
    INVALID;

}
