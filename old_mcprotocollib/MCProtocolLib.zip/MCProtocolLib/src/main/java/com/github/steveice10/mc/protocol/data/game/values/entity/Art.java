package com.github.steveice10.mc.protocol.data.game.values.entity;

public enum Art {

    KEBAB,
    AZTEC,
    ALBAN,
    AZTEC2,
    BOMB,
    PLANT,
    WASTELAND,
    POOL,
    COURBET,
    SEA,
    SUNSET,
    CREEBET,
    WANDERER,
    GRAHAM,
    MATCH,
    BUST,
    STAGE,
    VOID,
    SKULL_AND_ROSES,
    WITHER,
    FIGHTERS,
    POINTER,
    PIG_SCENE,
    BURNING_SKULL,
    SKELETON,
    DONKEY_KONG;

}
