package com.github.steveice10.mc.protocol.data.game.values.entity.player;

public enum BlockBreakStage {

    STAGE_1,
    STAGE_2,
    STAGE_3,
    STAGE_4,
    STAGE_5,
    STAGE_6,
    STAGE_7,
    STAGE_8,
    STAGE_9,
    STAGE_10,
    RESET;

}
