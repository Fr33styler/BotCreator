package com.github.steveice10.mc.protocol.data.game.values.window.property;

public interface WindowProperty {

}
