package com.github.steveice10.mc.protocol.data.game.values.entity;

public enum MinecartType implements ObjectData {

    NORMAL,
    CHEST,
    POWERED,
    TNT,
    MOB_SPAWNER,
    HOPPER,
    COMMAND_BLOCK;

}
