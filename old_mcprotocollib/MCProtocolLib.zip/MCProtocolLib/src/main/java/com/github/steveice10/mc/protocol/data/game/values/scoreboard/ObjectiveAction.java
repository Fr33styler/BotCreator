package com.github.steveice10.mc.protocol.data.game.values.scoreboard;

public enum ObjectiveAction {

    ADD,
    REMOVE,
    UPDATE;

}
