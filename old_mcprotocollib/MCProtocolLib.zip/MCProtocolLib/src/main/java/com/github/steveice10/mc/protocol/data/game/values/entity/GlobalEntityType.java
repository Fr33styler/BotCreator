package com.github.steveice10.mc.protocol.data.game.values.entity;

public enum GlobalEntityType {

    LIGHTNING_BOLT;

}
