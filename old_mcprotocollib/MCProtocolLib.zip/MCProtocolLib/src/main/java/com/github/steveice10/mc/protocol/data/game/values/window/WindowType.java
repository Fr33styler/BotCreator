package com.github.steveice10.mc.protocol.data.game.values.window;

public enum WindowType {

    GENERIC_INVENTORY,
    ANVIL,
    BEACON,
    BREWING_STAND,
    CHEST,
    CRAFTING_TABLE,
    DISPENSER,
    DROPPER,
    ENCHANTING_TABLE,
    FURNACE,
    HOPPER,
    VILLAGER,
    HORSE;

}
