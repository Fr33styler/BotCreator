package com.github.steveice10.mc.protocol.data.game.values.world.notify;

public interface ClientNotificationValue {
}
