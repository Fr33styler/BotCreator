package com.github.steveice10.mc.protocol.data;

public enum SubProtocol {
    HANDSHAKE,
    LOGIN,
    GAME,
    STATUS;
}
