package com.github.steveice10.mc.protocol.data.game.values.scoreboard;

public enum ScoreType {

    INTEGER,
    HEARTS;

}
