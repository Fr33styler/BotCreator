package com.github.steveice10.mc.protocol.data.game.values.world;

public interface Sound {
}
