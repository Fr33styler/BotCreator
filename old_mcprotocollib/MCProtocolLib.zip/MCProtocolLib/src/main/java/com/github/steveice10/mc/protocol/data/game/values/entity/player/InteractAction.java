package com.github.steveice10.mc.protocol.data.game.values.entity.player;

public enum InteractAction {

    INTERACT,
    ATTACK,
    INTERACT_AT;

}
